#' Calculate individual gene differential expresseion for each gene, This function should usually be called by "makeComparison".
#' @param Baseline Baseline is the matix of gene expressions at baseline, row names are gene names
#' @param PostTreatment PostTreatment is the matix of gene expressions after treatment, row names are gene names
#' @param paired, boolean paired: logical, whether the data is paired or not
#' @param min.variance.factor  constant for calculations
#' @param na.rm boolean arguments
#' @return expression
#' @export 

calcIndividualExpressions<-function(Baseline,PostTreatment,paired=FALSE,min.variance.factor=10^-6,na.rm=TRUE){

  ##########Some error checks
  if(length(dim(Baseline))!=2 | length(dim(PostTreatment))!=2){stop("Input Matrices need to be matrices... \n")}
  if(nrow(Baseline)!=nrow(PostTreatment)){stop("Input Matrices need to have the same number of genes \n")}
  if(sum(!(rownames(Baseline)%in%rownames(PostTreatment)))){stop("Input Matrices need to have the same list of genes. Gene names should be the row names \n")}
  if(ncol(Baseline)<2 | ncol(PostTreatment)<2 ){stop("Input Matrices need to have at least two columns \n")}

  #########Reorder PostTreatment
  PostTreatment<-PostTreatment[rownames(Baseline),]

#  if(!abs){
    ###########Paired
    if(paired){
  if(ncol(Baseline)!=ncol(PostTreatment)){
        stop("Input Matrices need to have the same number of columns when paired flag is on \n")
      }
      if(sum(!colnames(Baseline)%in%colnames(PostTreatment))){
        stop("Input Matrices need to have the same list of samples when paired flag is on \n")
      }
      PostTreatment = PostTreatment[,colnames(Baseline)]
      ##########First calculate the differential expression for individual genes
      Sums_Base<-rowSums(Baseline, na.rm=na.rm)
      Sums_Post<-rowSums(PostTreatment, na.rm=na.rm)
      Ns<-rowSums(!is.na(Baseline-PostTreatment), na.rm=na.rm)
      if(min(Ns)!=ncol(Baseline)){warning("Some NA's in data")}
      Sigmas_Base<-rowSums((Baseline-PostTreatment-(Sums_Base-Sums_Post)/Ns)^2,na.rm=na.rm)/(Ns-1)
      DOF<-Ns
      if(any(DOF<3, na.rm=T)){warning("Some degrees of freedom are below minimum. They have been set to 3.\nPlease refer to section 3.4 of the vignette for information on running qusage with small sample sizes.")}
      DOF[DOF<3]<-3
      Mean=(Sums_Post-Sums_Base)/Ns
      SD=sqrt(Sigmas_Base/Ns)
 }
    ###########Non Paired
    if(!paired){
      ##########First calculate the differential expression for individual genes
      Sums_Base<-rowSums(Baseline, na.rm=na.rm)
      Sums_Post<-rowSums(PostTreatment, na.rm=na.rm)
      Ns_Base<-rowSums(!is.na(Baseline), na.rm=na.rm)
      Ns_Post<-rowSums(!is.na(PostTreatment), na.rm=na.rm)
      if(min(Ns_Base)!=ncol(Baseline) | min(Ns_Post)!=ncol(PostTreatment)){warning("Some NA's in data")}
      Sigmas_Base<-rowSums((Baseline-(Sums_Base)/Ns_Base)^2,na.rm=na.rm)/(Ns_Base-1)
      Sigmas_Post<-rowSums((PostTreatment-(Sums_Post)/Ns_Post)^2,na.rm=na.rm)/(Ns_Post-1)
      ROWS<-rownames(Baseline)
      DOF<-Ni(Sigmas_Post+min.variance.factor,Sigmas_Base+min.variance.factor,Ns_Post,Ns_Base)
      #calculate degrees of freedom
      if(any(DOF<3, na.rm=T)){warning("Some degrees of freedom are below minimum. They have been set to 3.")}
      DOF[DOF<3]<-3
      Mean=(Sums_Post/Ns_Post-Sums_Base/Ns_Base)
      SD=sqrt(Sigmas_Base/Ns_Base+Sigmas_Post/Ns_Post)
    }
 sd.alpha = sqrt(SD^2+min.variance.factor)/SD
  sd.alpha[is.infinite(sd.alpha)] = 1

  dat = newQSarray(mean=Mean,
                SD=sqrt(SD^2+min.variance.factor),
                sd.alpha = sd.alpha,
                dof=DOF,
                var.method="Welch's"
  )
  dat
}
