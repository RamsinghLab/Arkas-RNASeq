#' Calculate individual gene differential expresseion for each gene This function should usually be called by "makeComparisonArm". this requires sigmaArm.cpp and sigmaSingle.cpp must be compiled in local environment, this method enforces that there are no NAs in the data set; not robust nor flexible however we want fast.
#' @param Baseline Baseline is the matix of gene expressions at baseline, row names are gene names
#' @param PostTreatment is the matix of gene expressions after treatment, row names are gene names
#' @param paired logical, whether the data is paired or not
#' @param min.variance.factor a minimum scalar constant
#' @return returns expression statistics for Welch's Method Expression
#' @import qusage
#' @export 


calcIndividualExpressionsArm<-function(Baseline,PostTreatment,paired=FALSE,min.variance.factor=10^-6){
  
  
  ##########Some error checks
  if(length(dim(Baseline))!=2 | length(dim(PostTreatment))!=2){stop("Input Matrices need to be matrices... \n")}
  if(nrow(Baseline)!=nrow(PostTreatment)){stop("Input Matrices need to have the same number of genes \n")}
  if(sum(!(rownames(Baseline)%in%rownames(PostTreatment)))){stop("Input Matrices need to have the same list of genes. Gene names should be the row names \n")}
  if(ncol(Baseline)<2 | ncol(PostTreatment)<2 ){stop("Input Matrices need to have at least two columns \n")}
 
 #by checking if there are any NA values and ensureing there do not exist any NA values, then we can say that the row sums of the NA values is equal to the number of columns. and do not have to check that. assuming this
 if(any(is.na(Baseline)) || any(is.na(PostTreatment)) ){
 stop("NA values are present in the expression matrix, please pluck out ...")
 }


 #########Reorder PostTreatment
  PostTreatment<-PostTreatment[rownames(Baseline),]

  ###########Paired
    if(paired){
      if(ncol(Baseline)!=ncol(PostTreatment)){
        stop("Input Matrices need to have the same number of columns when paired flag is on \n")
      }
  if(sum(!colnames(Baseline)%in%colnames(PostTreatment))){
        stop("Input Matrices need to have the same list of samples when paired flag is on \n")
      }
      PostTreatment = PostTreatment[,colnames(Baseline)]
      ##########First calculate the differential expression for individual genes 
    Ns<-ncol(Baseline) #ncol identical(ncol(Baseline,ncol(PostTreatment)) if NA enforced 
    qsList<-sigmaArm(Baseline,PostTreatment,Ns,min.variance.factor)
    qv<-lapply(qsList,function(x) as.vector(x))
    names(qv$Mean)<-attr(qsList$Mean,"names")
    names(qv$SD)<-attr(qsList$SD,"names")
     names(qv$SDAlpha)<-attr(qsList$SDAlpha,"names")

      if(any(qv$DOF<3)){warning("Some degrees of freedom are below minimum. They have been set to 3.\nPlease refer to section 3.4 of the vignette for information on running qusage with small sample sizes.")}
      qv$DOF[qv$DOF<3]<-3
      qv$SDAlpha[is.infinite(qv$SDAlpha)]=1
      dat = newQSarray(mean=qv$Mean,
                SD=qv$SD,
                sd.alpha = qv$SDAlpha,
                dof=qv$DOF,
                var.method="Welch's"
  )



    }
    ###########Non Paired
    if(!paired){
      ##########First calculate the differential expression for individual genes
     
    qsList<-sigmaSingle(Baseline,PostTreatment,min.variance.factor)
    qv<-lapply(qsList,function(x) as.vector(x))
    names(qv$Mean)<-attr(qsList$Mean,"names")
    names(qv$SD)<-attr(qsList$SD,"names")
     names(qv$sd.alpha)<-attr(qsList$sd.alpha,"names")
      #calculate degrees of freedom
if(any(qv$DOF<3)){warning("Some degrees of freedom are below minimum. They have been set to 3.")}
       qv$DOF[qv$DOF<3]<-3
     qv$sd.alpha[is.infinite(qv$sd.alpha)] = 1
    dat = newQSarray(mean=qv$Mean,
                SD=qv$SD,
                sd.alpha = qv$sd.alpha,
                dof=qv$DOF,
                var.method="Welch's"
  )


    }#if !paired
  
  dat
}

