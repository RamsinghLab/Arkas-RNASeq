##' A client package for QuSage
##'
##' \tabular{ll}{
##' Package: \tab speedSage \cr
##' Type: \tab Package \cr
##' Developed since: \tab 2016 \cr
##' License: \tab GPL (>=3) \cr
##' LazyLoad: \tab yes \cr
##' }
##'
##'Description: Computes the necessary statistics for gene set enrichment analys
##'is using Rcpp libraries for equal and non-equal variances between comparison groups. 
##' it handles the calculations of the degree of freedom, standard deviations,
##' and other computations.  For 1000 simulations the use of the sister
##' (Client) package garnered 34 percent acceleration in computation time.  
##' the second bottleneck which we did not address in this client package
##' is working on the aggregateGeneSet function in armadillo which calculates 
##' the convolution of each entry of every gene set.  This client package 
##' only addresses the bottlenecks found in makeComparisons, calculate 
##' variation inflation factor, and calculateIndividualExpressions. 
##'  Commands export PKG_CXXFLAGS=`Rscript -e "Rcpp:::CxxFlags()"`  export
##'  PKG_LIBS=`Rscript -e "Rcpp:::LdFlags()"` are suggested by Dirk E. for
##'  running C++ packages in R, and the NAMESPACE requires useDynLib(speedSage)
##' @name speedSage
##' @aliases speedSage
##' @docType package
##' @importFrom Rcpp evalCpp
##' @importFrom Rcpp sourceCpp
##' @import limma
##' @import Rcpp
##' @import qusage
##' @title speedSage
##' @useDynLib speedSage
##' @author Anthony R. Colombo, Timothy Triche Jr.
NULL

