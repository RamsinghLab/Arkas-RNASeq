//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>
#include <Rcpp.h>
#include <R.h>
using namespace arma;
using namespace Rcpp;
//' called by makeComparisonArm to calculate basic statistics using the limma fit option for variance equal assumptions in Qusage, this is the case for eBayes assumptions are not desired.
//' @param Xr limma contrasted fit sigma
//' @param Yr limma contrasted fit stdev.unscaled
//' @param Zr min variance factor input
//' @param Vr limm contrasted fit df.residual
//' @return List of SD , DOF and sd.alpha
//' @export
//[[Rcpp::export]]
List notbayesEstimation(NumericVector Xr, NumericMatrix Yr, NumericMatrix Zr, NumericMatrix Vr){

//List notbayesEstimation(SEXP Xs, SEXP Ys, SEXP Zs, SEXP Vs) {
//Rcpp::NumericVector Xr(Xs);
//Rcpp::NumericMatrix Yr(Ys);
//Rcpp::NumericMatrix Zr(Zs);
//Rcpp::NumericMatrix Vr(Vs);
int n = Yr.nrow(), k = Yr.ncol();
int l = Vr.nrow(), m = Vr.ncol();
arma::mat x(Xr.begin(),n,k,false); //fit2$sigma
arma::mat y(Yr.begin(),n,k,false); //fit2b$stdev.unscaled
arma::mat z(Zr.begin(),1,1,false); //min.variance.factor
arma::mat v(Vr.begin(),l,m,false); //fit2$df.residual


arma::mat sda(n,1);
arma::vec dof(n);
arma::vec sd(n);

sd  = sqrt(  (y%x)%(y%x) + as_scalar(z));
sda = sd/(x%y);
dof = v;
Rcpp::NumericVector Sd = Rcpp::wrap(sd);
Rcpp::NumericVector Sda = Rcpp::wrap(sda);
Rcpp::NumericVector DOF = Rcpp::wrap(dof);
   Sd.names() = Rcpp::List(Yr.attr("dimnames"))[0];
   Sda.names() = Rcpp::List(Yr.attr("dimnames"))[0];
 
return Rcpp::List::create( Rcpp::Named("SD") = Sd,
                           Rcpp::Named("DOF") =  DOF,
                           Rcpp::Named("sd.alpha") = Sda);
}
