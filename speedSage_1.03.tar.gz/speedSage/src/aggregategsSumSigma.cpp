//[[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <algorithm>
#include <vector>
#include <Rcpp.h>
#include <math.h>
#include <R.h>
using namespace arma;
using namespace Rcpp;
//'calculates the sd and mindof in order , names are assigned in R, as of now, there is no NA error checking.  not very robust
//' @param SDs standard deviations from geneResults returned by makeComparison
//' @param DOFs degrees of freedom from geneResults returned by makeComparison
//' @param geneSets a set of genes for enrichment testing
//' @export
//' @return a List with SumSigma and MinDof
//[[Rcpp::export]]
List aggregategsSumSigma(NumericVector SD, NumericVector DOF, List geneSet){
//List aggregategsSumSigma( SEXP SDs, SEXP DOFs, SEXP geneSets) {
//Rcpp::NumericVector SD(SDs);
//Rcpp::NumericVector DOF(DOFs);
//Rcpp::List geneSet(geneSets);  //for packaging with Rcpp SEXP not input


int n = SD.size();
int m = DOF.size();
int o = geneSet.size(); //we assume non-empty (reduce complexity)
arma::vec sumSigma(o); //there is a sumSigma for each geneSet
arma::vec finalDof(o);


//need to run the sapply function
for ( int i=0 ; i < o ; i++) { //running a for loop
 SEXP nn = geneSet[i];
 Rcpp::NumericVector index(nn);
 int p = index.size();
arma::vec test(p);
 //we subset before computing, and use the Rcpp index vector to avoid creating an unsigned vector as armadillo type
Rcpp::NumericVector sd = SD[index -1]; //converting to 0 based
Rcpp::NumericVector dof = DOF[index-1];
//fast copy pointer address without data cache copy armadillo variables
arma::vec asd(sd.begin(),sd.size(),false);
arma::colvec adof(dof.begin(),dof.size(),false);
test =(asd%asd)%(adof/(adof-2));
sumSigma(i) = sqrt(sum(test)); //summing the subsets
finalDof(i) = floor(min(adof)); 
}

  
return Rcpp::List::create( Rcpp::Named("SumSigma") = Rcpp::wrap(sumSigma),
                           Rcpp::Named("MinDof") = Rcpp::wrap(finalDof));
}
