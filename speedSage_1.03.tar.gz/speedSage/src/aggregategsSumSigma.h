#ifndef _speedSage_AGGREGATEGSSUMSIGMA_H
#define _speedSage_AGGREGATEGSSUMSIGMA_H

#include <RcppArmadillo.h>
#include <algorithm>
#include <vector>
#include <Rcpp.h>
#include <math.h>
#include <R.h>

using namespace arma;
using namespace Rcpp;
List aggregategsSumSigma( SEXP SDs, SEXP DOFs, SEXP geneSets);
#endif
